using System.Collections;
using System.Collections.Generic;
using System.Reflection;
using UnityEngine;
using UnityEngine.UI;

/// <summary>
/// Runs one level on top of the existing WaveManager: starts the waves on a timer, counts the
/// living enemies, fills the wave info in the HUD and decides victory or defeat.
///   Victory: the last wave has spawned and every enemy is dead.
///   Defeat:  the keep (the object the enemies march towards) is destroyed.
/// Nothing in other people's scripts is changed; the HUD numbers are written by reflection.
/// </summary>
public class LevelController : MonoBehaviour
{
    [Header("Waves")]
    [Tooltip("The WaveManager (with WaveBuilder and WaveFormations on the same object).")]
    [SerializeField] WaveManager waveManager;
    [SerializeField, Min(1)] int totalWaves = 5;
    [SerializeField, Min(0f)] float firstWaveDelay = 30f;
    [SerializeField, Min(0f)] float timeBetweenWaves = 45f;
    [Tooltip("Start the next wave early (after a short pause) when all enemies are dead.")]
    [SerializeField] bool skipWaitWhenCleared = true;
    [SerializeField, Min(0f)] float clearedPause = 5f;
    [Tooltip("Optional. Pressing it starts the next wave right away.")]
    [SerializeField] Button startWaveButton;

    [Header("Win and lose")]
    [Tooltip("Destroying this object loses the level. It needs a DBTest so the enemies target it.")]
    [SerializeField] DBTest keep;
    [SerializeField] WinLoseUI winLose;

    [Header("HUD")]
    [Tooltip("Optional. Leave empty to keep the HUD wave text unchanged.")]
    [SerializeField] InGameUI hud;

    // Private HUD fields of InGameUI that this script fills in (see PushToHud).
    static readonly BindingFlags PrivateInstance = BindingFlags.Instance | BindingFlags.NonPublic;
    FieldInfo _waveField, _maxWaveField, _enemiesField;

    // WaveBuilder forgets the enemies of earlier waves, so every wave is copied into this list.
    readonly List<UnitHealth> _enemies = new();
    WaveBuilder _builder;

    int _wave;
    bool _allWavesSpawned, _ended, _startNow;

    int AliveCount
    {
        get
        {
            // Dead units stay in the scene for a few seconds, so check isDead as well as null.
            _enemies.RemoveAll(e => e == null || e.isDead);
            return _enemies.Count;
        }
    }

    void Start()
    {
        if (waveManager == null || winLose == null || keep == null)
        {
            Debug.LogError("[LevelController] Assign the wave manager, win/lose UI and keep in the inspector.", this);
            enabled = false;
            return;
        }

        _builder = waveManager.GetComponent<WaveBuilder>();
        FindHudFields();
        if (startWaveButton != null) startWaveButton.onClick.AddListener(() => _startNow = true);
        StartCoroutine(RunWaves());
    }

    void Update()
    {
        if (_ended) return;

        PushToHud();

        // 'keep == null' is also true for a destroyed Unity object.
        if (keep == null) End(false);
        else if (_allWavesSpawned && AliveCount == 0) End(true);
    }

    IEnumerator RunWaves()
    {
        yield return WaitForNextWave(firstWaveDelay);

        for (_wave = 1; _wave <= totalWaves; _wave++)
        {
            SpawnWave();
            if (_wave == totalWaves) break;

            yield return WaitForNextWave(timeBetweenWaves);
            waveManager.EndWave(); // raises the budget for the next wave
        }
        _allWavesSpawned = true;
    }

    void SpawnWave()
    {
        waveManager.StartWave();
        // StartWave spawns instantly, so the builder now holds exactly this wave's enemies.
        foreach (UnitAIBase enemy in _builder.GetSpawnedEnemies())
        {
            if (enemy.TryGetComponent(out UnitHealth health)) _enemies.Add(health);
        }
    }

    // Counts in scaled time, so the speed buttons (0.5x / 1x / 2x) also affect the waves.
    IEnumerator WaitForNextWave(float pSeconds)
    {
        _startNow = false;
        for (float left = pSeconds; left > 0f && !_startNow; left -= Time.deltaTime)
        {
            // Only shorten the wait once a wave has run, not before the first one.
            if (_wave > 0 && skipWaitWhenCleared && AliveCount == 0 && left > clearedPause) left = clearedPause;
            yield return null;
        }
    }

    void End(bool pVictory)
    {
        _ended = true;

        if (pVictory) winLose.ShowVictory();
        else winLose.ShowDefeat();

        // Make sure the result and any new achievements are on disk.
        if (StatsTracker.Instance != null) StatsTracker.Instance.SaveNow();
    }

    // --- HUD -----------------------------------------------------------------------------------
    // InGameUI keeps its wave numbers in private serialized fields and refreshes its texts every
    // frame, so writing the fields is all that is needed.

    void FindHudFields()
    {
        if (hud == null) return;

        System.Type type = typeof(InGameUI);
        _waveField = type.GetField("wave", PrivateInstance);
        _maxWaveField = type.GetField("maxWave", PrivateInstance);
        _enemiesField = type.GetField("enemies", PrivateInstance);

        if (_waveField == null || _maxWaveField == null || _enemiesField == null)
        {
            Debug.LogWarning("[LevelController] InGameUI no longer has 'wave', 'maxWave' and 'enemies'. HUD not updated.", this);
            hud = null;
        }
    }

    void PushToHud()
    {
        if (hud == null) return;

        _waveField.SetValue(hud, _wave);
        _maxWaveField.SetValue(hud, totalWaves);
        _enemiesField.SetValue(hud, AliveCount);
    }
}